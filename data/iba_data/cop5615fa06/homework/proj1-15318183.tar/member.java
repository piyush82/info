import java.util.concurrent.*;
import java.net.*;
import java.io.*;
import java.lang.*;
import java.util.*;
import java.sql.Timestamp;
import java.security.*;


//this class is reaponsible to starting the process on a machine.
//It contains the void main function.
//It helps a node be a member of the multicast group
//It also defines whether a node is just a member of a group coordinator.
public class member
{
	public static String Pnum = null;
	public static int UniPort;
	public static String UniAddress;
	public static String UniName;
	public static String GroupKey = null;
	public static DatagramSocket LocalMember = null;
	public static boolean GroupLeader = false;
	public static long GLTS = 0;
	public static boolean INVALIDATE_GROUP = false;
	public static boolean LEFT_GROUP = false;
	
	//define the 3 channels
	public static int CHANNEL_HEARTBEAT = 5555;
	public static int CHANNEL_COMMUNICATION = 6666;
	public static int CHANNEL_NEWMEMBER = 7777;
	
	//file handling
	public static PrintWriter output = null;
	
	//election alrogithm
	public static boolean ELECTION = false;
	public static boolean ELECTION_ACCEPT = false;
	
	public static String GLPort;
	public static String GLAddress;
	
	static boolean EXIT_CODE = false;
	
	public static Date dateTime = new Date();
	
	//Main function
	public static void main(String[] args)
	{
		openFile(args[0]);
		startProcess(true);
	}
	
	//takes a boolean which tells it whether the function is running for the first time of after a leave group message
	static void startProcess(boolean TF)
	{
		initiateUnicast(TF);
		performGJOIN();
	}
	
	//Creates a log file
	static void openFile(String ProcessNum)
	{
		try
		{
			Pnum = "process" + ProcessNum + ".log";
			output = new PrintWriter(new FileWriter(Pnum));			
		}
		catch(IOException e)
		{
		}
	}
	
	//creates a unicast address and port to listen to the unicast requests
	static void initiateUnicast(boolean TF)
	{
		while(true)
		{
			try
			{
				//check for a random port
				UniPort = Math.round(10000 * (float)Math.random() + 1024);
				LocalMember = new DatagramSocket(UniPort);
				break;
			}
			catch(Exception e)
			{
				continue;
			}
		}
		
		try
		{
			
			UniAddress = InetAddress.getLocalHost().getHostAddress().toString();
			UniName = InetAddress.getLocalHost().getHostName().toString();
			
			if(TF)
			{
				output.write("Process Details: [host: " + UniName + " port: " + UniPort + "]\r\n");
				output.write("LOG FILE NAME: "+ Pnum.toUpperCase() + "\r\n");
			}
		}
		catch(UnknownHostException e)
		{
		}
	}
	
	//perform the GJOIN process
	static void performGJOIN()
	{
		String GJOIN;
		InetAddress NMJRC = null;
		MulticastSocket newMember = null;
		DatagramPacket joinrequest = null;
		
		try
		{
			GJOIN = "GJOIN " + UniAddress + " " + UniPort;
			System.out.println("GJOIN : " + GJOIN);
			
			//New Member Join Request Channel
			NMJRC = InetAddress.getByName("239.0.0.3");
	 		newMember = new MulticastSocket(member.CHANNEL_NEWMEMBER);
	 		joinrequest = new DatagramPacket(GJOIN.getBytes(), GJOIN.length(),NMJRC, member.CHANNEL_NEWMEMBER);
	 		newMember.send(joinrequest);
	 		
	 		Timestamp ts = new Timestamp(System.currentTimeMillis());
	 		output.write("SENT: GJOIN on channel [239.0.0.3:" + member.CHANNEL_NEWMEMBER + "] [SYSTEM TIMESTAMP " + ts.getTime() + "]\r\n");
	 		//Socket closed after work is done
	 		newMember.close();
		}
		catch(UnknownHostException e)
		{
		}
		catch(IOException e)
		{
		}
		
		try
		{
			//Check for WAIT, DENIED, ACCEPT reply
			byte[] buf = new byte[10000];
			DatagramPacket reply = new DatagramPacket(buf, buf.length);
			
			//Set timeout to 5 seconds
			LocalMember.setSoTimeout(5000);
			
			LocalMember.receive(reply);
			
			String ShowReply = new String(reply.getData()).substring(0,reply.getLength());

			if(ShowReply.equals("WAIT"))
			{
				System.out.println("RECV: WAIT at [" + UniName + " port: " + UniPort + "]");
				output.write("RECV: WAIT at [" + UniName + " port: " + UniPort + "]\r\n");
				try
				{
					LocalMember.setSoTimeout(10000);
					LocalMember.receive(reply);
					ShowReply = new String(reply.getData()).substring(0,reply.getLength());
					if(ShowReply.equals("DENIED"))
					{
						System.out.println("RECV: DENIED at [" + UniName + " port: " + UniPort + "]");
						output.write("RECV: DENIED at [" + UniName + " port: " + UniPort + "]\r\n");
						try
						{
							Thread.sleep(2000);
						}
						catch(InterruptedException e)
						{
						}
						performGJOIN();
					}
					else
					{
						StringTokenizer st = new StringTokenizer(ShowReply," ");
						if(st.nextToken().equals("ACCEPT"))
						{
							GroupKey = st.nextToken();
							System.out.println("RECV: ACCEPT at [" + UniName + " port: " + UniPort + "] GROUPKEY: " + GroupKey);
							output.write("RECV: ACCEPT at [" + UniName + " port: " + UniPort + "] GROUPKEY: " + GroupKey + "\r\n");
							JoinGroup();
						}
						else
						{
							/**/
							//Timeout expired so set the member as the group coordinator.
							System.out.println("GROUP-COORDINATOR [" + UniName + " port: " + UniPort + "]");
							output.write("GROUP-COORDINATOR [" + UniName + " port: " + UniPort + "]\r\n");
							GroupLeader = true;
							GroupCoordinator();
						}
					}
				}
				catch(SocketTimeoutException e)
				{
					//Timeout expired so set the member as the group coordinator.
					System.out.println("GROUP-COORDINATOR [" + UniName + " port: " + UniPort + "]");
					output.write("GROUP-COORDINATOR [" + UniName + " port: " + UniPort + "]\r\n");
					GroupLeader = true;
					System.out.println("Group Leader set to true");
					GroupCoordinator();
				}	
			}
			else 
			{
				if(ShowReply.equals("DENIED"))
				{
					System.out.println("RECV: DENIED at [" + UniName + " port: " + UniPort + "]");
					output.write("RECV: DENIED at [" + UniName + " port: " + UniPort + "]\r\n");
					try
					{
						Thread.sleep(2000);
					}
					catch(InterruptedException e)
					{
					}
					performGJOIN();
				}
				else
				{
					StringTokenizer st = new StringTokenizer(ShowReply," ");
					if(st.nextToken().equals("ACCEPT"))
					{
						GroupKey = st.nextToken();
						System.out.println("RECV: ACCEPT at [" + UniName + " port: " + UniPort + "] GROUPKEY: " + GroupKey);
						output.write("RECV: ACCEPT at [" + UniName + " port: " + UniPort + "] GROUPKEY: " + GroupKey + "\r\n");
						GLAddress = st.nextToken();
						GLPort    = st.nextToken();
						JoinGroup();
					}
					else
					{
						/**/
						//Timeout expired so set the member as the group coordinator.
						System.out.println("GROUP-COORDINATOR [" + UniName + " port: " + UniPort + "]");
						output.write("GROUP-COORDINATOR [" + UniName + " port: " + UniPort + "]\r\n");
						GroupLeader = true;
						GroupCoordinator();
					}
				}
			}
			
			//Close the unicast connection since its work is done here
			LocalMember.close();
			
		}
		catch(SocketTimeoutException e)
		{
			//Timeout expired so set the member as the group coordinator.
			System.out.println("GROUP-COORDINATOR [" + UniName + " port: " + UniPort + "]");
			output.write("GROUP-COORDINATOR [" + UniName + " port: " + UniPort + "]\r\n");
			GroupLeader = true;
			System.out.println("Group Leader set to true...outter function");
			GroupCoordinator();
		}
		catch(IOException e)
		{
		}
	}
	
	
	static void GroupCoordinator()
	{
		//Set the new group coordinator
		//Subscribe to the multicast channels
		multicastchannel.LeaveGroupDecision();
		multicastchannel.ListenUnicastPort();
		multicastchannel.CommChannel();
		multicastchannel.NewMemberChannel();
		multicastchannel.HeartbeatChannel();
		CreateGroupKey();
	}
	
	static void JoinGroup()
	{
		//Subscribe to the multicast channels
		multicastchannel.LeaveGroupDecision();
		multicastchannel.ListenUnicastPort();
		multicastchannel.CommChannel();
		multicastchannel.NewMemberChannel();
		multicastchannel.HeartbeatChannel();
	}
	
	public static void CreateGroupKey()
	{
		Random rkey = new Random(dateTime.getTime());
		long val = rkey.nextLong();
		if(val == 0)val = -1;
    	if(val > 0) val = -val;
		GroupKey = Long.toHexString(val).toString().toUpperCase();
		
		GLAddress = UniAddress;
		GLPort    = Integer.toString(UniPort).trim();
	}
	
	
	
	//this function takes the ascii byte array data from the MD5 algorithm and converts it to a HEX string
	public static String convertToHex(byte[] data) 
	{
		StringBuffer buf = new StringBuffer();
	    for (int i = 0; i < data.length; i++) 
		{
			int _HB = (data[i] >>> 4) & 0x0F;
	        int _2HB = 0;
	        do 
			{
		    	if ((0 <= _HB) && (_HB <= 9))
		        	buf.append((char) ('0' + _HB));
		        else
		        	buf.append((char) ('a' + (_HB - 10)));
		        _HB = data[i] & 0x0F;
			}while(_2HB++ < 1);
		}
	    return buf.toString();
	}

}