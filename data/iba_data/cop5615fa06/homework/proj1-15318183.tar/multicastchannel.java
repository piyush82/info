import java.util.concurrent.*;
import java.net.*;
import java.io.*;
import java.lang.*;
import java.util.*;
import java.sql.Timestamp;
import java.security.*;

//creates a main thread for all the 3 channels.
//these threads create sockets for these channels
//these threads are closed only if the process exits or if a node leaves a group
public class multicastchannel
{
	
	public static InetAddress HBC = null, CC = null, NMC = null;
	public static MulticastSocket HBCSocket = null, CCSocket = null, NMCSocket = null;
	
	//creates a socket for the heart beat channel and starts a thread for the same
	static void HeartbeatChannel()
	{
		try
		{
			HBC = InetAddress.getByName("239.0.0.1");
			HBCSocket = new MulticastSocket(member.CHANNEL_HEARTBEAT);
	 		HBCSocket.joinGroup(HBC);
	 		
	 		HBCclass hbc = new HBCclass(HBC,HBCSocket);
			Thread t = new Thread(hbc);
			t.start();
		}
		catch(UnknownHostException e)
		{
		}
		catch(IOException e)
		{
		}
	}
	
	//creates a socket for the communication channel and starts a thread for the same
	static void CommChannel()
	{
		try
		{
			CC = InetAddress.getByName("239.0.0.2");
			CCSocket = new MulticastSocket(member.CHANNEL_COMMUNICATION);
	 		CCSocket.joinGroup(CC);
	 		
	 		CCclass cc = new CCclass(CC,CCSocket);
			Thread t = new Thread(cc);
			t.start();
			
			CCmemberelect ccme = new CCmemberelect(CC,CCSocket);
			Thread tt = new Thread(ccme);
			tt.start();
	 		
	 	}
	 	catch(UnknownHostException e)
		{
		}
		catch(IOException e)
		{
		}
	}
	
	//creates a socket for the new member channel and starts a thread for the same
	static void NewMemberChannel()
	{
		try
		{
			NMC = InetAddress.getByName("239.0.0.3");
			NMCSocket = new MulticastSocket(member.CHANNEL_NEWMEMBER);
	 		NMCSocket.joinGroup(NMC);
	 		
	 		NMCclass nmc = new NMCclass(NMC,NMCSocket);
			Thread t = new Thread(nmc);
			t.start();
	 		
	 	}
	 	catch(UnknownHostException e)
		{
		}
		catch(IOException e)
		{
		}	
	}
	
	//creates a thread that decides on leaving of the group at periodic intervals
	static void LeaveGroupDecision()
	{
	 	LeaveGroupDecisionClass LvGrp = new LeaveGroupDecisionClass();
		Thread t = new Thread(LvGrp);
		t.start();
	}
	
	//create a thread to listen to the unicast port
	static void ListenUnicastPort()
	{
		ListenUnicastClass luc = new ListenUnicastClass();
		Thread t = new Thread(luc);
		t.start();
	}
	
}

//decides whether the member should leave the class or not and acts accordingly
//sends LGROUP message on the communication channel
//if the member decides to leave the group, it closes all the socket connections it had made to listen to the
//3 communication channels and waits for some time beore starting the process all over again.
class LeaveGroupDecisionClass implements Runnable
{
	public static boolean lvflag = false;
	
	LeaveGroupDecisionClass()
	{
		lvflag = false;
	}
	
	public void run()
	{
		try
		{
			while(!lvflag && !member.EXIT_CODE)
			{
				Thread.sleep(10000);
				int rand = (int)(1000 * Math.random());
				if(rand < 500)
					lvflag = true;
				else
					lvflag = false;
				if(lvflag)
				{
					String LGROUPrequest = null;
					LGROUPrequest = member.GroupKey + " LGROUP " + member.UniAddress + " " + member.UniPort;
					InetAddress CC = InetAddress.getByName("239.0.0.2");
			 		MulticastSocket leaveMember = new MulticastSocket(member.CHANNEL_COMMUNICATION);
			 		DatagramPacket groupreply = new DatagramPacket(LGROUPrequest.getBytes(), LGROUPrequest.length(),CC, member.CHANNEL_COMMUNICATION);
			 		leaveMember.send(groupreply);
			 		System.out.println("Sent reply for LGROUP request is : " + LGROUPrequest);
			 		member.output.write("SENT: " + member.GroupKey + " LGROUP on channel [239.0.0.2:" + member.CHANNEL_COMMUNICATION + "]\r\n");
			 		
			 		//Socket closed after work is done
			 		leaveMember.close();
			 		member.LEFT_GROUP = true;
			 		
			 		int alpha;
			 		alpha = 500 + (int)(250*Math.random());
			 		Thread.sleep(alpha);
			 		
			 		multicastchannel.CCSocket.close();
		 			multicastchannel.HBCSocket.close();
		 			multicastchannel.NMCSocket.close();
			 		
			 		member.startProcess(false);			 		
				}		
			}
		}
		catch(UnknownHostException e)
		{
		}
		catch(IOException e)
		{
		}	
		catch(InterruptedException e)
		{
		}
	}	
}


//Listens to the unicast port and address to check for an Elect message from the group coordinator.
//Reply with the answer alongwith the MD5 hash for the group coordinator to map the answer to the correct requester
class ListenUnicastClass implements Runnable
{
	public void run()
	{
		try
		{
			DatagramSocket ElectYN = new DatagramSocket(member.UniPort);
			byte[] buf = new byte[10000];
			
			while(!LeaveGroupDecisionClass.lvflag && !member.EXIT_CODE)
			{
				DatagramPacket recv = new DatagramPacket(buf, buf.length);
				try
				{
					ElectYN.setSoTimeout(1000);
					ElectYN.receive(recv);
					
					String recvData = new String(recv.getData()).substring(0,recv.getLength());
				
					StringTokenizer st = new StringTokenizer(recvData," ");
					String ELECTANS = st.nextToken();
					
					if(ELECTANS.equals("ELECT"))
		 			{
		 				String StrYESNO = st.nextToken().trim();
		 				if(StrYESNO.equals("YES") || StrYESNO.equals("NO"))
		 				{
		 					String electmd5digest = st.nextToken();
		 					//since the above msg is an elect answer we compute the reply
		 					//Compare with the reply and the md5 digest to map to the correct reply
		 					if(StrYESNO.equals("YES") && electmd5digest.equals(electionalgorithm.StrMD5))
							{
								electionalgorithm.elect_yes = electionalgorithm.elect_yes + 1;
							}	
							else
							{
								if(StrYESNO.equals("NO") && electmd5digest.equals(electionalgorithm.StrMD5))	
								{
									electionalgorithm.elect_no = electionalgorithm.elect_no + 1;
								}	
							}	
		 				}
		 			}
				}
				catch(SocketTimeoutException e)
				{
				}	
			}
			ElectYN.close();
		}
		catch(UnknownHostException e)
		{
		}
		catch(IOException e)
		{
		}	
	}	
}	
