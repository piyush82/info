import java.util.concurrent.*;
import java.net.*;
import java.io.*;
import java.lang.*;
import java.util.*;
import java.security.*;
import java.lang.Runtime;


//starts the parent program by remotely starting 6 processes on 6 different machines
public class start
{
	
	public static int NUMBER_OF_PROCESSES = 6;
	
	public static void main(String args[]) throws IOException
	{	
		String[] Members = new String[6];
		
		Members[0] = "sun114-41.cise.ufl.edu";
		Members[1] = "sun114-42.cise.ufl.edu";
		Members[2] = "sun114-43.cise.ufl.edu";
		Members[3] = "sun114-44.cise.ufl.edu";
		Members[4] = "sun114-45.cise.ufl.edu";
		Members[5] = "sun114-46.cise.ufl.edu";
		//Start the members
		System.out.println("System has started.");
		System.out.println("Please wait while the remote processes are started.");
		
		String path = System.getProperty("user.dir");    
		
		for(int i = 0; i < NUMBER_OF_PROCESSES; i++)
		{
			path = System.getProperty("user.dir");    
			Runtime.getRuntime().exec("ssh " + Members[i] + " cd " + path + " ; java member " + (i+1));
			try
			{
				Thread.sleep(5000);
			}
			catch(InterruptedException e)
			{
			}
			
		}
		
		
		InterruptExecution IE = new InterruptExecution();
		Thread t = new Thread(IE);
		t.start();
		try
		{
			t.join();
		}
		catch(InterruptedException e)
		{
		}
		
		
				
	}
}

class InterruptExecution implements Runnable
{
	static String line = "a";
	static int shutdn = 0;
	
	
	
	public void run()
	{
    	BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
    	try 
    	{
    		System.out.println("All remote processes started.");
    		System.out.println("Press 'q' and press Enter Key for System Shutdown.");
    		while(!line.equals("q"))
    		{
    			line = in.readLine();
      			System.out.println("Key pressed....|" + line + "|");
    		}
    		
  			System.out.println("System is shutting down...please wait");
  			
  			listenSHUTDOWN lsd = new listenSHUTDOWN();
		 	Thread tt = new Thread(lsd);
		 	tt.start();
			
			//String to send...
    		String EXITmsg = "EXIT a9c35d24860d73b6 " + listenSHUTDOWN.UniAddress + " " + listenSHUTDOWN.UniPort;
    		InetAddress CC = InetAddress.getByName("239.0.0.2");
		 	MulticastSocket shutdown = new MulticastSocket(member.CHANNEL_COMMUNICATION);
		 	DatagramPacket shutdownmsg = new DatagramPacket(EXITmsg.getBytes(), EXITmsg.length(),CC, member.CHANNEL_COMMUNICATION);
		 	
		 	
			
			
			while(shutdn != start.NUMBER_OF_PROCESSES)
			{
				shutdown.send(shutdownmsg);
				Thread.sleep(1000);
			}
		 	shutdown.close();
		 	System.out.println("SYSTEM SHUTDOWN SUCCESSFUL.");
    	}
    	catch(Exception e) 
    	{
    	}
	}
}

//waits in a loop till system shutdown is initiated
//once its initiated, the program sends a multicast message for EXIT on the communication channel
//it keeps on sending this message till it gets replies from all the remotely running process
//this is to prevent any process missing on the EXIT message and getting converted into a runaway process
//once the count of replies reaches the number of processes the parent has started, it shuts itself down
//here the program on the remote machine might still take some time to shutdown depending on what processing its 
//doin currently
//so a SYSTEM SHUTDOWN indicates that all the remote processes have received the EXIT message and that thhey will
//take the exit process in their own hands from there.
class listenSHUTDOWN implements Runnable
{
	static byte[] buf;
	static DatagramPacket reply = null;
	static int UniPort;
	static String UniAddress = null;
	static DatagramSocket LocalMember = null;
	static String ShowReply = null;
	
	listenSHUTDOWN()
	{
		try
		{
			//String expected back....
			UniPort = Math.round(10000 * (float)Math.random() + 1024);
			UniAddress = InetAddress.getLocalHost().getHostAddress().toString();
			LocalMember = new DatagramSocket(UniPort);
		}
		catch(Exception e)
		{
		}
		
	}
	
	public void run()
	{
		try
		{
			while(InterruptExecution.shutdn != start.NUMBER_OF_PROCESSES)
			{
				buf = new byte[10000];
				reply = new DatagramPacket(buf, buf.length);
				LocalMember.receive(reply);
				ShowReply = new String(reply.getData()).substring(0,reply.getLength());
				if(ShowReply.equals("a9c35d24860d73b6"))
					InterruptExecution.shutdn++;
			}
		}
		catch(SocketTimeoutException e)
		{
		}
		catch(IOException e)
		{
		}
	}
}