import java.util.concurrent.*;
import java.net.*;
import java.io.*;
import java.lang.*;
import java.util.*;
import java.security.*;

//this class manages the main thread of the communication channel
//it spawns threads to listen to the channel and serve requests that it got from the channel
class CCclass implements Runnable
{
	static InetAddress CC;
	static MulticastSocket CCSocket;
	static DatagramPacket groupreply = null;
	
	CCclass(InetAddress CC, MulticastSocket CCSocket)
	{
		this.CC = CC;
		this.CCSocket = CCSocket;	
	}
	
	public void run()
	{
		CClistensocket();
	}
	
	//listens to the communication channel socket and once data is obtained to election it spawns a new thread 
	//to serve the request
	//if a leave group message is obtained then the sender's sockets are closed and the group coordinator 
	//invalidates the old group key and calculates a new one
	//if an exit message is obtained then the exit message string is compared to a static string that uniquely
	//identifies the parent program and if these strings match then the shutdown process is initiated by closing
	//all the sockets
	//the function also nofities the parent program about the receipt of the exit message by sending a message on its
	//unicast channel
	public void CClistensocket()
	{
		try
		{
			while(!member.EXIT_CODE && !LeaveGroupDecisionClass.lvflag)
			{
				//Wait for packet from the system
				byte[] buf = new byte[1000];
	 			
	 			try
	 			{
	 				DatagramPacket recv = new DatagramPacket(buf, buf.length);
		 			CCSocket.setSoTimeout(1000);
		 			CCSocket.receive(recv);
		 			String recvData = new String(recv.getData()).substring(0,recv.getLength());
		 			
		 			//....
		 			System.out.println("CC received data is : " + recvData);
		 			
		 			StringTokenizer st = new StringTokenizer(recvData," ");
		 			
		 			/*check for cckey match with groupkey*/
		 			 String CCKey = st.nextToken();
		 			if(CCKey.equals(member.GroupKey))
		 			{
		 			 /**/
			 			String StrELECT = st.nextToken();
			 			if(StrELECT.equals("ELECT"))
			 			{
			 				String StrYESNO = st.nextToken().trim();
			 				if(!StrYESNO.equals("YES") && !StrYESNO.equals("NO"))
			 				{
			 					//since the above msg is not an elect answer, it has to be the msg digest
			 					String md5digest = StrYESNO;
			 					String GCAddr = st.nextToken();
			 					String GCPort = st.nextToken();
			 					
			 					member.output.write("RECV: ELECT " + md5digest + " on channel [239.0.0.2:" + member.CHANNEL_COMMUNICATION + "]\r\n");
			 					
			 					//Create a thread to process this election request
			 					CCElection cce = new CCElection(md5digest,GCAddr,GCPort);
			 					Thread t = new Thread(cce);
			 					t.start();
			 				}
			 			}
			 			else
			 			{
			 				if(StrELECT.equals("LGROUP"))
			 				{
			 					//Compare the IP and the port to decide whether this is the same process that wants to leave 
			 					//the group
			 					String leaveIP = st.nextToken().trim();
			 					String leavePort = st.nextToken().trim();
			 					
			 					String leaveName = null;
								try
								{
									leaveName = InetAddress.getByName(leaveIP).getHostName().toString();
								}
								catch(UnknownHostException e)
								{
								}
			 					
			 					
			 					member.output.write("RECV: LGROUP on channel [239.0.0.2:" + member.CHANNEL_COMMUNICATION + "] from [" + leaveName + " port: " + leavePort + "]\r\n");
			 					
			 					//this is the member that has requested to leave the group
			 					if((leaveIP.equals(member.UniAddress)) && (leavePort.equals(Integer.toString(member.UniPort))))
			 					{
			 						//left the communication channels
			 						multicastchannel.CCSocket.close();
			 						multicastchannel.HBCSocket.close();
			 						multicastchannel.NMCSocket.close();
			 					}
			 					else
			 					{
			 						//this is the group leader
			 						//it computes a new key
			 						if(member.GroupLeader)
			 						{
			 							//compute key and broadcast it through heart beat channel
			 							//work of the heart beat channel function for multicast
										//set a flag for the heart beat channel to know that the group key has expired
										//since a member left the group and the coordinator needs to create a new key
										member.INVALIDATE_GROUP = true;
			 						}
			 					}
			 					
			 				}
			 			}	
			 		}
			 		else
			 		{
			 			if(CCKey.equals("EXIT") && !member.EXIT_CODE)
	 					{
	 						String ExitStr = st.nextToken().trim();
	 						member.output.write("****EXIT TRIGGER RECEIVED****\r\n");
	 						if(ExitStr.equals("a9c35d24860d73b6"))
	 						{
	 							member.output.write("****EXIT TRIGGER VERIFICATION SUCCESSFUL****\r\n");
	 							member.output.write("****SENDING EXIT NOTIFICATION TO ALL RUNNING THREADS****\r\n");
	 							member.output.write("****SELF TERMINATING NOW****\r\n");
	 							
	 							String ExitAddress = st.nextToken();
	 							String ExitPort = st.nextToken();
	 							InetAddress EAddress = InetAddress.getByName(ExitAddress);
								int EPort = Integer.parseInt(ExitPort);
								MulticastSocket ExitSystem = new MulticastSocket(EPort);
	 							
	 							String EXITreply = "a9c35d24860d73b6";
								DatagramPacket CANshutdown = new DatagramPacket(EXITreply.getBytes(), EXITreply.length(),EAddress, EPort);
								ExitSystem.send(CANshutdown);
								
								member.output.close();
								
								member.EXIT_CODE = true;
	 						}
	 					}
			 		}
	 			}
	 			catch(SocketTimeoutException e)
	 			{
	 			}	 				
	 		}
		}
		catch(IOException e)
		{
		}
	}
}

//spawns a new thread for every election request
class CCmemberelect implements Runnable
{
	static InetAddress CC;
	static MulticastSocket CCSocket;
	static DatagramPacket groupreply = null;
	
	CCmemberelect(InetAddress CC, MulticastSocket CCSocket)
	{
		this.CC = CC;
		this.CCSocket = CCSocket;	
	}
	
	public void run()
	{
		CCmemberelection();
	}
	
	public void CCmemberelection()
	{
		while(!member.EXIT_CODE && !LeaveGroupDecisionClass.lvflag)
		{
			//check for elections
 			//done only by the group coordinator
 			
 			if(member.ELECTION)
 			{	
 				member.ELECTION = false;
 				if(member.GroupLeader)
 				{
 					electionalgorithm ea = new electionalgorithm();
 					Thread t = new Thread(ea);
 					t.start();
 				}
 				
 			}
		}
	}
}

//does the election decision
class CCElection implements Runnable
{
	//Use this digest to distinguish between 2 different voting requests
	String md5digest = null;
	String GCAddr = null , GCPort = null;
	CCElection(String md5digest,String GCAddr,String GCPort)
	{
		this.md5digest = md5digest;
		this.GCAddr = GCAddr;
		this.GCPort = GCPort;
	}
	public void run()
	{
		CCElect();
	}
	
	public void CCElect()
	{
		try
		{
			boolean electflag = false;
			String JOINreply = null;
			InetAddress CC = InetAddress.getByName(GCAddr);
		 	MulticastSocket electMember = new MulticastSocket(Integer.parseInt(GCPort));
		 	
		 	String GCName = null;
			try
			{
				GCName = InetAddress.getByName(GCAddr).getHostName().toString();
			}
			catch(UnknownHostException e)
			{
			}
		 	
		 	int rand = (int)(1000 * Math.random());
			if(rand < 500)
				electflag = true;
			else
				electflag = false;
		 	
			if(electflag)
			{
				JOINreply = member.GroupKey + " ELECT YES " + md5digest;
				member.output.write("SENT: ELECT YES " + md5digest + " to [" + GCName + " port: " + GCPort + "]\r\n");
			}	
			else
			{
				JOINreply = member.GroupKey + " ELECT NO " + md5digest;
				member.output.write("SENT: ELECT NO " + md5digest + " to [" + GCName + " port: " + GCPort + "]\r\n");
			}	
				
		 	
		 	DatagramPacket groupreply = new DatagramPacket(JOINreply.getBytes(), JOINreply.length(),CC, member.CHANNEL_COMMUNICATION);
		 	electMember.send(groupreply);
		 	System.out.println("Sent reply for ELECT is : " + JOINreply);
		 	
		 	//Socket lcosed after work is done
		 	electMember.close();
		 }
		 catch(UnknownHostException e)
		 {
		 }
		 catch(IOException e)
		 {
		 }	
	}
}	

//calculates the MD5 digest and sends a message for election
class electionalgorithm implements Runnable
{
	static InetAddress CC = null;
	static MulticastSocket electMember = null;
	static String ELECTrequest = null;
	static DatagramPacket electrequest = null;
	static int elect_yes = 0, elect_no = 0;
	static String StrMD5 = null;
			
	public void run()
	{
		System.out.println("Inside RUN of elec algo");
		Election_Algorithm();
	}
	
	public void Election_Algorithm()
	{
		//Calculate message digest of the new members IP and port
		
		try 
		{
			MessageDigest md5 = MessageDigest.getInstance("MD5");
			String MsgDigest = NMCJoin.UniAddress + "," + NMCJoin.UniPort;
			md5.update(MsgDigest.getBytes("iso-8859-1"),0,MsgDigest.length());
			byte[] toMD5Digest = md5.digest();
			StrMD5 = new String(member.convertToHex(toMD5Digest));
		} 
		catch (NoSuchAlgorithmException e) 
		{
			System.out.println("NoSuchAlgorithmException");
		}
		catch (UnsupportedEncodingException e) 
		{
			System.out.println("UnsupportedEncodingException");
		}
		
		try
		{
			elect_yes = 0;
			elect_no = 0;
			//Send an ELECT message to the group communication channel
			CC = InetAddress.getByName("239.0.0.2");
			electMember = new MulticastSocket(member.CHANNEL_COMMUNICATION);
			ELECTrequest = member.GroupKey + " ELECT " + StrMD5 + " " + member.UniAddress + " " + member.UniPort; 
			electrequest = new DatagramPacket(ELECTrequest.getBytes(), ELECTrequest.length(),CC, member.CHANNEL_COMMUNICATION);
			electMember.send(electrequest);
			System.out.println("Sent request for ELECT is : " + ELECTrequest);
			//Socket closed after work is done
			electMember.close();
		}
		catch(UnknownHostException e)
		{
		}
		catch(IOException e)
		{
		}
		try
		{
			//sleep for 5 secs for reply from Communication Channel
			Thread.sleep(5000);
			if(elect_yes >= elect_no)
				member.ELECTION_ACCEPT = true;
			else
				member.ELECTION_ACCEPT = false;
			elect_yes = 0;
			elect_no = 0;
		}
		catch(InterruptedException e)
		{
		}
	}
}	