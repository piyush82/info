import java.util.concurrent.*;
import java.net.*;
import java.io.*;
import java.lang.*;
import java.util.*;
import java.sql.Timestamp;
import java.security.*;

//this class manages the main thread of the heartbeat channel
//it spawns threads to listen to the channel and serve requests that it got from the channel
class HBCclass implements Runnable
{
	static InetAddress HBC;
	static MulticastSocket HBCSocket;
	
	HBCclass(InetAddress HBC, MulticastSocket HBCSocket)
	{
		this.HBC = HBC;
		this.HBCSocket = HBCSocket;	
	}
	
	
	public void run()
	{
		//Create a thread to send the heart beat message
		HeartbeatMessage HBMsg = new HeartbeatMessage();
		Thread t = new Thread(HBMsg);
		t.start();
		
		//Create a thread to listen to the heart beat channel
		HBClistensocket();
	}
	
	public void HBClistensocket()
	{
		try
		{
			while(!member.EXIT_CODE && !LeaveGroupDecisionClass.lvflag)
			{
				//Wait for packet from the system
				byte[] buf = new byte[1000];
				try
				{
					DatagramPacket recv = new DatagramPacket(buf, buf.length);
					HBCSocket.setSoTimeout(1000);
		 			HBCSocket.receive(recv);
		 			String recvData = new String(recv.getData()).substring(0,recv.getLength());
		 			
		 			//start a thread to process the heartbeat message
		 			HEARTBEATClass hrtbt = new HEARTBEATClass(recvData);
		 			Thread t = new Thread(hrtbt);
		 			t.start();
				}
				catch(SocketTimeoutException e)
				{
				}
	 			
	 		}
	 	}
	 	catch(UnknownHostException e)
		{
		}
		catch(IOException e)
		{
		}	
	}
}	 


class HeartbeatMessage implements Runnable
{
	private Timestamp ts = null;
	
	public void run()
	{
		int alpha;
		try
		{
			while(!member.EXIT_CODE && !LeaveGroupDecisionClass.lvflag)
			{
				//Wait for some time before sending the periodic heartbeat message
				alpha = 2000 + 250 + (int)(500*Math.random());
				Thread.sleep(alpha);
				SendHBMsg();
	 		}
	 	}
	 	catch(InterruptedException e)
		{
		}	
	}
	
	public void SendHBMsg()
	{
		try
		{
			//Send an Heartbeat message to the group member heart-beat channel
			InetAddress HBC = InetAddress.getByName("239.0.0.1");
			MulticastSocket LiveMember = new MulticastSocket(member.CHANNEL_HEARTBEAT);
			
			//Calculate timestamp of the system
			ts = new Timestamp(System.currentTimeMillis()); 
	 		long longts = ts.getTime();
	 		
			String LivenessMsg = "HEARTBEAT " + longts + " " + member.UniAddress + " " + member.UniPort;
			
			//Check if the timestamp of the heart beat message is less than 5 seconds from the heart beat message
			//obtained from the group coordinator
			//If it is more then set the member as a group coordinator himself
			
			if(((longts - member.GLTS)  > 5000) && member.GLTS != 0)
			{
				//set itself as the group coordinator
				member.GLAddress = member.UniAddress;
				member.GLPort    = Integer.toString(member.UniPort);
				member.GroupLeader = true;
			}
			
			//Send the groupkey if member is leader
			//Create group key if the INVALIDATE_GROUP flag is set to true
			//This is done when a member leaves the group
			if(member.GroupLeader)
			{
				if(member.INVALIDATE_GROUP)
				{
					member.INVALIDATE_GROUP = false;
					member.CreateGroupKey();					
				}
					
				LivenessMsg = LivenessMsg + " " + member.GroupKey;
			}	 
			//Send the liveness heartbeat message	 
			DatagramPacket liverequest = new DatagramPacket(LivenessMsg.getBytes(), LivenessMsg.length(),HBC, member.CHANNEL_HEARTBEAT);
			LiveMember.send(liverequest);
			
			member.output.write("SENT: SELF HEARTBEAT on channel [239.0.0.1:" + member.CHANNEL_HEARTBEAT + "]\r\n");
			//Socket closed after work is done
			LiveMember.close();
		}
		catch(UnknownHostException e)
		{
		}
		catch(IOException e)
		{
		}
	}
}

class HEARTBEATClass implements Runnable
{
	String recvData = null;
	
	HEARTBEATClass(String recvData)
	{
		this.recvData = recvData;
	}
	
	public void run()
	{
		StringTokenizer st = new StringTokenizer(recvData," ");
		String HEARTBEAT = st.nextToken();
		long HostTime;
		
		if(HEARTBEAT.equals("HEARTBEAT"))
		{		
			String HostTS = st.nextToken().trim();
			HostTime = Long.parseLong(HostTS);
			
			String HostAddr = st.nextToken();
			String HostPort = st.nextToken();
			String HostName = null;
			try
			{
				HostName = InetAddress.getByName(HostAddr).getHostName().toString();
			}
			catch(UnknownHostException e)
			{
			}
			
			
			//Check if the host is the group coordinator
			//Set the new member key obtained from the group coordinator
			//The if statement indicates a protection to check whether the current group coordinator 
			//is still the group coordinator and sends the group key.
			//If we have the group key then update the timestamp also
			if(st.hasMoreTokens())
			{
				member.GroupKey = st.nextToken();
				member.GLTS = HostTime;
				member.output.write("GROUP-COORDINATOR [" + HostName + " port: " + HostPort + "]\r\n");	
			}
			else
			{
				member.output.write("RECV: HEARTBEAT on channel [239.0.0.1:" + member.CHANNEL_HEARTBEAT + "] from [" + HostName + " port: " + HostPort + "]\r\n");
			}
				
			
			String GroupLeaderMD5 = CalcMD5(member.GLAddress,member.GLPort);
			String IncomingHostMD5 = CalcMD5(HostAddr,HostPort);
			String LocalHostMD5 = CalcMD5(member.UniAddress,Integer.toString(member.UniPort));
			
			
			//Compare and set values of the group coordinator
			//Compares the Hash of IP address and port of 3 nodes and decides on the group coordinator
			//1. Host
			//2. Group Coordinator
			//3. The node that sent the heart beat message
			int result = GroupLeaderMD5.compareTo(IncomingHostMD5);
			if(result < 0)
			{
				result = GroupLeaderMD5.compareTo(LocalHostMD5);
				if(result > 0)
				{
					member.GLAddress = member.UniAddress;
					member.GLPort	 = Integer.toString(member.UniPort);
					member.GroupLeader = true;
				}
				else
				{
					member.GroupLeader = false;
				}
			}	
			else
			{
				result = IncomingHostMD5.compareTo(LocalHostMD5);	
				if(result < 0)
					{
					member.GLAddress = HostAddr;
					member.GLPort	 = HostPort;
					member.GroupLeader = false;
				}
				else
					{
					member.GLAddress = member.UniAddress;
					member.GLPort	 = Integer.toString(member.UniPort);
					member.GroupLeader = true;
				}
			}	
		}
	}
	
	
	//function to calculate the MD5 hash of IPaddress and IPport
	public String CalcMD5(String MD5Address, String MD5Port)
	{
		String StrMD5 = null;
		
		try 
		{
			MessageDigest md5 = MessageDigest.getInstance("MD5");
			String MsgDigest = MD5Address + "," + MD5Port;
			md5.update(MsgDigest.getBytes("iso-8859-1"),0,MsgDigest.length());
			byte[] toMD5Digest = md5.digest();
			StrMD5 = new String(member.convertToHex(toMD5Digest));
		} 
		catch (NoSuchAlgorithmException e) 
		{
			System.out.println("NoSuchAlgorithmException");
		}
		catch (UnsupportedEncodingException e) 
		{
			System.out.println("UnsupportedEncodingException");
		}
		return StrMD5;
	}
	
}