import java.util.concurrent.*;
import java.net.*;
import java.io.*;
import java.lang.*;
import java.util.*;
import java.security.*;

//this class manages the main thread of the new join request channel
//it spawns threads to listen to the channel and serve requests that it got from the channel
class NMCclass implements Runnable
{
	
	static InetAddress NMC;
	static MulticastSocket NMCSocket;
	static DatagramPacket groupreply = null;
	
	NMCclass(InetAddress NMC, MulticastSocket NMCSocket)
	{
		this.NMC = NMC;
		this.NMCSocket = NMCSocket;	
	}
	
	
	public void run()
	{
		System.out.println("Inside NMC runnable");
		NMClistensocket();
	}
	
	public void NMClistensocket()
	{
		try
		{
			while(!member.EXIT_CODE && !LeaveGroupDecisionClass.lvflag)
			{
				System.out.println("Listening to NMC socket");
				byte[] buf = new byte[1000];
				try
				{
					DatagramPacket recv = new DatagramPacket(buf, buf.length);
					NMCSocket.setSoTimeout(1000);
		 			NMCSocket.receive(recv);
		 			String recvData = new String(recv.getData()).substring(0,recv.getLength());
		 			
		 			StringTokenizer st = new StringTokenizer(recvData," ");
		 			
		 			String GJoin = st.nextToken();
		 			
		 			if(GJoin.equals("GJOIN") && member.GroupLeader)
		 			{
		 				String UniAddress = st.nextToken();
						String UniPort = st.nextToken();
			
		 				//Create a thread to serve this request
		 				NMCJoin nmcjoin = new NMCJoin(UniAddress ,UniPort);
		 				Thread t = new Thread(nmcjoin);
						t.start();
		 			}
				}
				catch(SocketTimeoutException e)
				{
				}
	 					
			}
		}
		catch(IOException e)
		{
		}	
	}
	
}


class NMCJoin implements Runnable
{
	static String UniAddress = null,UniPort = null;
	static DatagramPacket groupreply = null;
	static String recvData = null;
	
	NMCJoin(String UniAddress ,String UniPort)
	{
		this.UniAddress = UniAddress;
		this.UniPort = UniPort;
	}
	public void run()
	{
		NMCJoinMe();
	}
	//Group Leader will service the JOIN request
	void NMCJoinMe()
	{
		try
		{
			InetAddress GuestAddress = InetAddress.getByName(UniAddress);
			int GuestPort = Integer.parseInt(UniPort);
			MulticastSocket newMember = new MulticastSocket(GuestPort);
			
			Thread.sleep(2000);
			//Send a wait message to the incoming GJOIN request
			String JOINreply = "WAIT";
			groupreply = new DatagramPacket(JOINreply.getBytes(), JOINreply.length(),GuestAddress, GuestPort);
			newMember.send(groupreply);
			
			System.out.println("Entering the ELECT system");
			member.ELECTION = true;
			//sleep for 6 secs for reply from Communication Channel
			Thread.sleep(6000);
			
			//Decide the reply based on the total ELECT YES and NO obtained in 5 secs.
			System.out.println("Out of the ELECT system");
			
			//the flag ELECTION_ACCEPT is set accordingly
			if(member.ELECTION_ACCEPT)
			{
				member.ELECTION_ACCEPT = false;
				JOINreply = "ACCEPT " + member.GroupKey + " " + member.GLAddress + " " + member.GLPort;
				groupreply = new DatagramPacket(JOINreply.getBytes(), JOINreply.length(),GuestAddress, GuestPort);
				newMember.send(groupreply);
				System.out.println("Sent reply for ACCEPT is : " + JOINreply);
			}
			else
			{
				member.ELECTION_ACCEPT = false;
				JOINreply = "DENIED";
				groupreply = new DatagramPacket(JOINreply.getBytes(), JOINreply.length(),GuestAddress, GuestPort);
				newMember.send(groupreply);
				System.out.println("Sent reply for DENIED is : " + JOINreply);
			}	
			
			//Socket closed after work is done
			newMember.close();
		}
		catch(IOException e)
		{
		}
		catch(InterruptedException e)
		{
		}
	}
}